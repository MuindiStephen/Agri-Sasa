package com.steve_md.smartmkulima.model.requests

data class EmailOTPRequest(
    val otp:String
)
