package com.steve_md.smartmkulima.model.responses

data class EmailSignUpResponse (val message: String)