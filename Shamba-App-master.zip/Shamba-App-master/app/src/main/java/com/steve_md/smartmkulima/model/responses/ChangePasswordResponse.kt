package com.steve_md.smartmkulima.model.responses

data class ChangePasswordResponse(
    val success: String
)