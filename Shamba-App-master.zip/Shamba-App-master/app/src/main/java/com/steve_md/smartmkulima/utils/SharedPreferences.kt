package com.steve_md.smartmkulima.utils

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext

class SharedPreferences (
    @ApplicationContext context:Context
        ) {

}