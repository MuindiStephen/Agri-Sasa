package com.steve_md.smartmkulima.model.responses

data class PhoneOTPResponse (
    val smsMessage: String
        )
