package com.steve_md.smartmkulima.model.requests

data class PhoneOTPRequest (val otp:String)