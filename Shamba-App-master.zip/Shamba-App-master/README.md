# SmartMkulima App
## UI/UX Designs URL
https://xd.adobe.com/view/df0c0eb0-e5a1-4751-a003-6561680f3e2d-8a5f/grid

## Intro
- This is an android app that provides a solution based on AgriTech industry in particular.

## Project purpose 
The proposed solution for this android app is a platform to help farmers get sufficient knowledge in agriculture including the best tools, methods, and best practices to ensure that they improve quality control of their farming. It is a form of digitizing the accessibility of training materials to be available to all farmers. The platform also offers a way in which the farmers can hire farm equipments at affordable prices just the way people hire cars because some farm equipments are expensive. The platform will also introduce a way in which farmers can apply for insurance by paying insurance premium, a platform that connects farmers with available AgriTech companies.

## Getting Started

## Requirements

## Demo

##
-   WORK IN PROGRESS [ALL MODULE FEATURE IMPLEMENTATION IN PROGRESS]




